// $().ready(function(){
//     $("signupForm").validate({
//         rules: {
//             name: "required",
//         },
//         {
//             email: "required",
//         },

//     });
// })