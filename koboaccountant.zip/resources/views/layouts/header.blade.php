<header id="header">
  <div class="headerr">
  <div class="container-fluid">
    <div id="logo" class="pull-left">
      <a href="/"><img src="img/logo.png" alt="" title="" / class="logo"></a>
    </div>

    <nav id="nav-menu-container">
      <ul class="nav-menu">
        <li class="menu-active"><a href="/">Home</a></li>
        <li class="menu"><a href="/about">About Us</a></li>
        <li class="menu"><a href="/blog">Blog</a></li>
        <!-- <li><a href="contact.html">Contact</a></li> -->
      </ul>
    </nav>
  </div>
</div>
</header>
