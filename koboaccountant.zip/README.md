# koboaccountant
Koboaccountant is a platform established to provide Professional Accounting Services (PAS) to Business Startups, Small and Medium scale enterprises (and Individuals) who prior to now weren’t able to access this services (PAS) largely due to the affordability (cost of hiring an Accountant or a Financial Consultant). 
We therefore structured our value added services with the aim of ensuring startups and SMEs have proper financial records, access to Professional advice, and as a consequence, grow into the business that will shape Africa and indeed the world.
